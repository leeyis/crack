/*===========================================================================*/
struct magicnr_s
{
 uint32_t magic_number;		/* magic number */
};
typedef struct magicnr_s magicnr_t;
#define	MAGICNR_SIZE (sizeof(magicnr_t))
/*===========================================================================*/
