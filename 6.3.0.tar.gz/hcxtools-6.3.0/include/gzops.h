#define GZIPMAGICNUMBER		0x8b1f
#define DEFLATE			0x08
#define CHUNK			0x4000
#define windowBits		15
#define ENABLE_ZLIB_GZIP	32
